1. The function for the program 'dijkstra.c' starts from line number 1178 in the file 'graph.c'.
2. You can ignore other functions before line number 1178 in the file 'graph.c'.
3. To run the program, type 'make' and then './dijkstra.out' in the terminal without quotes.
4. Purpose of the program is to find shortest path between two vertices in a weighted graph using Dijkstra's Algorithm.